﻿namespace ImplementationMethodeExtensionCsharp
{
    public class Etudiant
    {
        public string nom { get; set; }
        public string prenom { get; set; }
        public int note { get; set; }
    }
}
